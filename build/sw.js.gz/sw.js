var __wpo = {
  "assets": {
    "main": [
      "/ced611daf7709cc778da928fec876475.eot",
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/runtime~main.c61edb6e0970e3920507.js",
      "/"
    ],
    "additional": [
      "/vendor.59bdf39c3407d6fe9a31.chunk.js",
      "/1.9c1b3e793c048e257b47.chunk.js",
      "/2.eb663ebc3f5370694338.chunk.js",
      "/3.d307013d2765bb0020d0.chunk.js",
      "/4.dd57f55ac130d98b32e0.chunk.js",
      "/5.401c2811a2c94508f5d4.chunk.js",
      "/6.a96d50e9bddd5b03e6af.chunk.js",
      "/7.846e3abe33916858b01f.chunk.js",
      "/8.f065b28e42d06939a59d.chunk.js",
      "/9.a80196343a11a383b86c.chunk.js",
      "/10.629b4fb2bbef41b98833.chunk.js",
      "/11.36f9bb58c08d03a9b699.chunk.js",
      "/12.243586556a5eff38019f.chunk.js",
      "/main.8fac700daa293cc28a49.chunk.js",
      "/15.bb1484d3389d7ecd632b.chunk.js",
      "/16.4d9fd00fa5325bc60578.chunk.js",
      "/17.ab36b867689fa9ecd8b6.chunk.js",
      "/18.eb30f240682127f1a95b.chunk.js",
      "/19.2347e3d629674587c3d2.chunk.js",
      "/20.5b27eb803150d4540ef7.chunk.js",
      "/21.59fe32d5d89b63d68be4.chunk.js",
      "/22.3e2e1a4de38d3987aea3.chunk.js",
      "/23.4ed5a0b62dbd2bc106f7.chunk.js",
      "/24.3a2bedda08dd968c5c3e.chunk.js",
      "/25.17e4be55444418f1430f.chunk.js",
      "/26.f55afec68d6e088c7d41.chunk.js",
      "/27.66134d2edd5b81ef2412.chunk.js",
      "/28.ed5f1dc8607a5aca0dcb.chunk.js",
      "/29.75ffd4d780c836ace0be.chunk.js",
      "/30.9721e4edb2b013b9c09e.chunk.js",
      "/31.de41613f3f085861f53b.chunk.js",
      "/32.1d3e4223234214905379.chunk.js",
      "/33.fc669d1b58141abe4057.chunk.js",
      "/34.280e781fb4d134cf2582.chunk.js",
      "/35.0e90d1fbc593c5fe6809.chunk.js",
      "/36.1a23c65fceb3a3892f39.chunk.js",
      "/37.e5ac555b8934eec8cc6e.chunk.js",
      "/38.1210c38f0074874c6bf8.chunk.js",
      "/39.1d73159807b2db362c8b.chunk.js",
      "/40.e454541b67ccb4e69cb3.chunk.js",
      "/41.77e0e9223e7b2eeb2282.chunk.js",
      "/42.256edbce4e5fae4bc950.chunk.js",
      "/43.e82fd046d31d63f242c3.chunk.js",
      "/44.de67332dc7515b8f5cf4.chunk.js",
      "/45.3158cec34f887a3f1c37.chunk.js",
      "/46.c4fd0b450f9454feb256.chunk.js",
      "/47.dc179a2d09880caed4ca.chunk.js",
      "/48.4d7b81b9efc4d4c1d478.chunk.js",
      "/49.60e3ca228f9a83b18c32.chunk.js",
      "/50.4518478d75e019233bd6.chunk.js",
      "/51.bc03fc8426a6c0cb38f4.chunk.js",
      "/52.f249beac1a48130e9e6f.chunk.js",
      "/53.4e837e448994b249fece.chunk.js",
      "/54.aa79f0f6e666d8886235.chunk.js",
      "/55.de8af1471d3d7e371405.chunk.js",
      "/56.25a7dbae446788629882.chunk.js",
      "/57.22a49c50a544e94d65c9.chunk.js",
      "/58.43eae21b8070400b0d0f.chunk.js",
      "/59.92298b3db9bc41330ecb.chunk.js",
      "/60.13dbfe622cd4ae187af8.chunk.js",
      "/61.0ae63a6c0e6c627b0c80.chunk.js",
      "/62.fc7a88446f29685f3dba.chunk.js",
      "/63.8208635a21d030617cca.chunk.js",
      "/64.978262f12998cd3cf2d0.chunk.js",
      "/65.b33f0b3a35569b39b3e8.chunk.js",
      "/66.d9410e8436c6f6eab41e.chunk.js",
      "/67.77bde3f6b921d697e8df.chunk.js",
      "/68.bb0d3483b7cccaf19c3a.chunk.js",
      "/69.a8da41b3bed12d7355c7.chunk.js",
      "/70.bb8404ae6b08bca45f7f.chunk.js",
      "/71.6035c0272d72ac2e1dc5.chunk.js",
      "/72.bdfe59eb92f987e6355e.chunk.js",
      "/73.b03c6c266c9804282b19.chunk.js",
      "/74.3471ffe57a99bfa12d09.chunk.js",
      "/75.0464f0e064d6878db920.chunk.js",
      "/76.599640346c34146dbb45.chunk.js",
      "/77.0bdbc612f585f19e205c.chunk.js",
      "/78.3b62192d75e4f1d2a5e0.chunk.js",
      "/79.7707494e8d7acc7a1778.chunk.js",
      "/80.7edc540c858ea93d9d18.chunk.js",
      "/81.a5636e1ea769c3eb8903.chunk.js",
      "/82.1a80d0ab205e393ef306.chunk.js",
      "/83.21a95d8d05611106f75a.chunk.js",
      "/84.5a9c22db2f0e3ae6f1c6.chunk.js",
      "/85.087569dafbf16f68ce0f.chunk.js",
      "/86.7b06ac3aabf02c731b4d.chunk.js",
      "/87.66dad76cd8c8efc7235d.chunk.js",
      "/88.10b0ec3b0349836812bf.chunk.js",
      "/89.8e18af4f3d62b2416ad9.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "7c285c265a562bef15d0ffcf967c599c9478a588": "/vendor.59bdf39c3407d6fe9a31.chunk.js",
    "73247c3f55769eadcb9d12198d0ddb8d6a273d35": "/1.9c1b3e793c048e257b47.chunk.js",
    "0dcc9e4a8937a676928839cbcf5347d4ba281ea7": "/2.eb663ebc3f5370694338.chunk.js",
    "7d8761303d4599c7c9af622cdf20987453099f43": "/3.d307013d2765bb0020d0.chunk.js",
    "26cb80d2fba8f15f671ab1f4048f67b0539498dd": "/4.dd57f55ac130d98b32e0.chunk.js",
    "6acd0754a2b37743ab8cc69f49d0a23560a51b61": "/5.401c2811a2c94508f5d4.chunk.js",
    "59675323687408917a2b111ece1a70d9d56f81ec": "/6.a96d50e9bddd5b03e6af.chunk.js",
    "26a0bfb012d6e0155927ca55d32c15acc77757cf": "/7.846e3abe33916858b01f.chunk.js",
    "1eadf56179342fbbfa1ca0f0a20ee0a7ef8284c1": "/8.f065b28e42d06939a59d.chunk.js",
    "c108db430a0f75c4367893c28b2d5d9682b7046f": "/9.a80196343a11a383b86c.chunk.js",
    "d98a5c1039348fc4a93a5b173f91fd650d4aae75": "/10.629b4fb2bbef41b98833.chunk.js",
    "857e3765a44c21288f4d7f891c0a4e13096760aa": "/11.36f9bb58c08d03a9b699.chunk.js",
    "656dcce017b6d053b254342ebd39453def1aa3e8": "/12.243586556a5eff38019f.chunk.js",
    "6d6a7cfc184a45428e9c24bdd11d65fd205eb83b": "/main.8fac700daa293cc28a49.chunk.js",
    "dd79c2502c979d8c54e60aab004189b83222fcc9": "/runtime~main.c61edb6e0970e3920507.js",
    "93b89bab733c705e20e610ac322bfebfa8f0fbed": "/15.bb1484d3389d7ecd632b.chunk.js",
    "2dc21b738fe25390941cad81e6809e68b2b41775": "/16.4d9fd00fa5325bc60578.chunk.js",
    "e7e4fa1c090e7d6044b1870352d189a09ad2976d": "/17.ab36b867689fa9ecd8b6.chunk.js",
    "eafae10a072225f7efa4bd0000cde3bef5a766d4": "/18.eb30f240682127f1a95b.chunk.js",
    "9041d24c24c84ead05f79ba4f2acc433053ff3fb": "/19.2347e3d629674587c3d2.chunk.js",
    "aed9646ca57a568bac0b563de165e8bfb6e3b707": "/20.5b27eb803150d4540ef7.chunk.js",
    "45024d94ccd25724ebcdea65415e21b3bdadcf34": "/21.59fe32d5d89b63d68be4.chunk.js",
    "7f9d53841140478bb040b4ba2a8e0467269c62f5": "/22.3e2e1a4de38d3987aea3.chunk.js",
    "495378fa5a87c28b38b0b02b86f1253fd7bf2df0": "/23.4ed5a0b62dbd2bc106f7.chunk.js",
    "335d352ae08b3df8355a7f57578e8f9a4588a48b": "/24.3a2bedda08dd968c5c3e.chunk.js",
    "76e1782f0a0da856b637a1a4197742cee849bb56": "/25.17e4be55444418f1430f.chunk.js",
    "ad5fbd8d4218473a77b8371a9070ded35ebf3876": "/26.f55afec68d6e088c7d41.chunk.js",
    "502b268a6fed303f157e8651fa627a4b093838eb": "/27.66134d2edd5b81ef2412.chunk.js",
    "8866850ba4ac256b7a021841d3f7f3a163ca553c": "/28.ed5f1dc8607a5aca0dcb.chunk.js",
    "92733d967955091b2320cb9c61c0f467bca853e7": "/29.75ffd4d780c836ace0be.chunk.js",
    "242b5da8d1be953f7f72a3098acf56c9e7d5493e": "/30.9721e4edb2b013b9c09e.chunk.js",
    "513e0e17c562fe74b35491c79637674246fdb0a8": "/31.de41613f3f085861f53b.chunk.js",
    "ef4533246371976cc1f779b22df317ae2687160b": "/32.1d3e4223234214905379.chunk.js",
    "6cbcb71a1d8784d5ff9b759ae05cf32c22d145a4": "/33.fc669d1b58141abe4057.chunk.js",
    "fddd6b8208981e7894c1a9844f1ec4dc2a8d0e5f": "/34.280e781fb4d134cf2582.chunk.js",
    "ce0a999bda101760059f66aaf166e7687012973d": "/35.0e90d1fbc593c5fe6809.chunk.js",
    "c6f4571ea3ee96ddb2c89f2d878b7ab0bc4e0446": "/36.1a23c65fceb3a3892f39.chunk.js",
    "8d4da604e67cf35051146c8d3ad8b0dbbda570ab": "/37.e5ac555b8934eec8cc6e.chunk.js",
    "f83b442a0afc0edbe5685e36e670af92e047ad28": "/38.1210c38f0074874c6bf8.chunk.js",
    "ff7e72e3c5f54b83e97164d210a1a21e1048183a": "/39.1d73159807b2db362c8b.chunk.js",
    "03a8c740ee262e07203ba80d0ef878db09278494": "/40.e454541b67ccb4e69cb3.chunk.js",
    "8eed4299cb862c683fd573fce15351aeedb6abd1": "/41.77e0e9223e7b2eeb2282.chunk.js",
    "9019d49bab4207d8ca6839b8009b4381460c2b64": "/42.256edbce4e5fae4bc950.chunk.js",
    "4198a2b2a7e98ee539fe95aafc234d7d6fab5d97": "/43.e82fd046d31d63f242c3.chunk.js",
    "3dd5e1651393ab21c10c768ed5e70327dc10225b": "/44.de67332dc7515b8f5cf4.chunk.js",
    "0cd4a73ab204999098e23e46b353ebe483182996": "/45.3158cec34f887a3f1c37.chunk.js",
    "ee4c5a2e1908a1882b8f3abe0cc9995488577670": "/46.c4fd0b450f9454feb256.chunk.js",
    "91845745db71558244ef6b59f6b339b37018ccd1": "/47.dc179a2d09880caed4ca.chunk.js",
    "1845d5b12f17d5e830915f73da29ec3c37358009": "/48.4d7b81b9efc4d4c1d478.chunk.js",
    "9e9f046356d10ad5ea3b3c62825ffabcff043b73": "/49.60e3ca228f9a83b18c32.chunk.js",
    "078ec63d6150dc97dfd1492df52d4695c6dcc3ad": "/50.4518478d75e019233bd6.chunk.js",
    "cd6affacc1048adb8415f88344ee93ad0ec6f8ff": "/51.bc03fc8426a6c0cb38f4.chunk.js",
    "802eb6fcb897b0b3883fb0c4b46057e3b46cc50a": "/52.f249beac1a48130e9e6f.chunk.js",
    "97cd7c5826fb7fb278bdbc77a9a948f857b4bfcb": "/53.4e837e448994b249fece.chunk.js",
    "7fd0fa3a04dc3b1b83d32bf0577713de37e1c6fe": "/54.aa79f0f6e666d8886235.chunk.js",
    "64387e25063af370efd21079c48d994dc6ca8079": "/55.de8af1471d3d7e371405.chunk.js",
    "103480a140cb116b638895e1481e9e4c997cce17": "/56.25a7dbae446788629882.chunk.js",
    "8a90199281ca8f0778659902ff64b0ff893580e3": "/57.22a49c50a544e94d65c9.chunk.js",
    "11f4f1a014a57e661cfa09e208bd5d3dc607eeee": "/58.43eae21b8070400b0d0f.chunk.js",
    "aaec0e7afed17a5aec06f9269d108b49434b41b0": "/59.92298b3db9bc41330ecb.chunk.js",
    "65b57b452c8f0b4813b9b265b39c7d04974e97bf": "/60.13dbfe622cd4ae187af8.chunk.js",
    "3758fcc8857703207668568dc48f499998b6e337": "/61.0ae63a6c0e6c627b0c80.chunk.js",
    "494befb8e507802528589e06bfd48e2df7207df9": "/62.fc7a88446f29685f3dba.chunk.js",
    "ce804a1d7daf0e31943d1836533b9730cd2086b7": "/63.8208635a21d030617cca.chunk.js",
    "dd8c0b982b3793bb2d95b07796eb0de804eb0c78": "/64.978262f12998cd3cf2d0.chunk.js",
    "75bce172cede0e61a3130cd4a23034d306fb675e": "/65.b33f0b3a35569b39b3e8.chunk.js",
    "d2670e56ea2154b7095a63f6ca93098940c701ad": "/66.d9410e8436c6f6eab41e.chunk.js",
    "b22b97c195bd3fc0130b709080409329fb639c11": "/67.77bde3f6b921d697e8df.chunk.js",
    "6c63aa2cacfc87cbe3a7f0a9d2b4fd0175389422": "/68.bb0d3483b7cccaf19c3a.chunk.js",
    "de7499d623fca408216377fd1c26c15096867c18": "/69.a8da41b3bed12d7355c7.chunk.js",
    "55ca995646fd447f3d1729339ac2f5c48a432834": "/70.bb8404ae6b08bca45f7f.chunk.js",
    "bc2bcc5a04e96a05c0595a567a68dc5ec50bf5e1": "/71.6035c0272d72ac2e1dc5.chunk.js",
    "f164436ac4b00e9c431d9581ffaaa46b40394ad9": "/72.bdfe59eb92f987e6355e.chunk.js",
    "844cb72dd3c0c44c0d1a432492687f492eb5c4dd": "/73.b03c6c266c9804282b19.chunk.js",
    "f1a5021c8183a9edc316dc07bb94454d7a78adab": "/74.3471ffe57a99bfa12d09.chunk.js",
    "76b417112275d6283eeb6a164d12295d083066d0": "/75.0464f0e064d6878db920.chunk.js",
    "b6ada8aa100596472424d10c851952b4801045df": "/76.599640346c34146dbb45.chunk.js",
    "5dee1afb8d6f5fc067fc2c6e2afd1106b7a4952a": "/77.0bdbc612f585f19e205c.chunk.js",
    "6ef853e8db8aded7779d9a53bd1826e042b874b9": "/78.3b62192d75e4f1d2a5e0.chunk.js",
    "f787127db5717f18a413371631fb763e32327e92": "/79.7707494e8d7acc7a1778.chunk.js",
    "5bac97f02c6735fc9d7ecc986646518fa7e5ee0c": "/80.7edc540c858ea93d9d18.chunk.js",
    "501b17a61a6223eecf6604b3077c93003f1ea7a3": "/81.a5636e1ea769c3eb8903.chunk.js",
    "7f32a97db1de8c3421bf7b4b404ab821ce626da9": "/82.1a80d0ab205e393ef306.chunk.js",
    "bd50e176a439c3a96c79f9ad7d8591ae80e2ce9b": "/83.21a95d8d05611106f75a.chunk.js",
    "3562703a91a0ee2129c3fd34580d831b529e6198": "/84.5a9c22db2f0e3ae6f1c6.chunk.js",
    "3f4d86fb361ecabd85de192a63638c6c2d2d90a8": "/85.087569dafbf16f68ce0f.chunk.js",
    "35df4e80f5230c6707cd6a92264a031cc828089f": "/86.7b06ac3aabf02c731b4d.chunk.js",
    "63c38e0236be6945537670b5ef3caa21bf2ac528": "/87.66dad76cd8c8efc7235d.chunk.js",
    "e844948c1f32454dba8a263dad37fe04ef762b28": "/88.10b0ec3b0349836812bf.chunk.js",
    "d5dc09edd67c0e2a78365dbccd17ac5bdc62daa5": "/89.8e18af4f3d62b2416ad9.chunk.js",
    "c209b0ad2bfd9100210a6f0ce1dcab363f3ac400": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "3/30/2022, 12:13:12 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });