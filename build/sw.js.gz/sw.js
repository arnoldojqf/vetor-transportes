var __wpo = {
  "assets": {
    "main": [
      "/ced611daf7709cc778da928fec876475.eot",
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/runtime~main.f32c982bcd33a896a0d1.js",
      "/"
    ],
    "additional": [
      "/vendor.59bdf39c3407d6fe9a31.chunk.js",
      "/1.9c1b3e793c048e257b47.chunk.js",
      "/2.eb663ebc3f5370694338.chunk.js",
      "/3.d307013d2765bb0020d0.chunk.js",
      "/4.dd57f55ac130d98b32e0.chunk.js",
      "/5.e9620447ba5aa95ffc33.chunk.js",
      "/6.764bcca204cb21ef4ac7.chunk.js",
      "/7.81a31ff7ebe26813af0d.chunk.js",
      "/8.f502f41c4d719f9f4af5.chunk.js",
      "/9.978b08f7f77c60d1e4e8.chunk.js",
      "/10.6748c662e62e3a2a25a2.chunk.js",
      "/11.ff4abc55df2508e6c425.chunk.js",
      "/main.e34a3d376afe4b48c07f.chunk.js",
      "/14.0026277a08bb5c452c36.chunk.js",
      "/15.a3f6f36ccd9b87200921.chunk.js",
      "/16.38c7627154a6b5712530.chunk.js",
      "/17.f10d30aae678168130e4.chunk.js",
      "/18.a697ff56dc42eadd60e7.chunk.js",
      "/19.4229ce6b7a53a87acea4.chunk.js",
      "/20.36c7cb3334daa256380e.chunk.js",
      "/21.1b476c3ebb3ec6e9fc71.chunk.js",
      "/22.bc8c9836810cda9cccc6.chunk.js",
      "/23.8d5c6fffcaafd9bdcf29.chunk.js",
      "/24.dad69ee71a8bbb74c680.chunk.js",
      "/25.7464002c267fcdac64a9.chunk.js",
      "/26.31724035366728cac998.chunk.js",
      "/27.9c1a0eb57785e3a9b332.chunk.js",
      "/28.6b844bce9bc81b4c26de.chunk.js",
      "/29.f71e68f9293154102085.chunk.js",
      "/30.08e2d71c0f613830e428.chunk.js",
      "/31.929b6cb1b42c3576dc04.chunk.js",
      "/32.3fa9deaa255367aab1d8.chunk.js",
      "/33.a8119f82fcbe2b6c14f2.chunk.js",
      "/34.22e479bd03d6b2691667.chunk.js",
      "/35.2efaa6fdcb9206cc89c3.chunk.js",
      "/36.651d2e0665ff616bbfea.chunk.js",
      "/37.b66761dcce9fa4ca6c71.chunk.js",
      "/38.34eecc6c765957fb7f74.chunk.js",
      "/39.1232cc558baad593bfd7.chunk.js",
      "/40.9165549873878002b108.chunk.js",
      "/41.96c8d8ef9170c422c291.chunk.js",
      "/42.4a4edbf9f573ee3a1958.chunk.js",
      "/43.30834dc915161558a598.chunk.js",
      "/44.4c6554a60adcb5865a4f.chunk.js",
      "/45.3945d12d75a4cea57137.chunk.js",
      "/46.f3804bbea6c6d2778442.chunk.js",
      "/47.7ba122d8950ce4f9dc9b.chunk.js",
      "/48.6ba75f0259af5b981f5b.chunk.js",
      "/49.9bf32306ff767322b48e.chunk.js",
      "/50.9a27e6696c03a03e7d36.chunk.js",
      "/51.04ac1583b58cb924a861.chunk.js",
      "/52.6e467181788fa3a92be2.chunk.js",
      "/53.74d8fd21d2651c8d9bc0.chunk.js",
      "/54.bedc8d4eb796855a2edd.chunk.js",
      "/55.8376e2c23abd2eeeade9.chunk.js",
      "/56.733a12a5d7eb1c3b2fd8.chunk.js",
      "/57.fc43ee9bfc263dda2c68.chunk.js",
      "/58.995a92808244c5b4fbce.chunk.js",
      "/59.742146166e65b2bc38b4.chunk.js",
      "/60.e7b24574eeb9bcebed86.chunk.js",
      "/61.a4d38112c1bf44e699e8.chunk.js",
      "/62.77e541ea9ceb88222beb.chunk.js",
      "/63.2693efb9a5136888f4bc.chunk.js",
      "/64.fdaa90800546d3169b4b.chunk.js",
      "/65.629eec2602fa8edceeca.chunk.js",
      "/66.6de6fca17ea3a2d1307f.chunk.js",
      "/67.fabed1cfd19a093c8057.chunk.js",
      "/68.51d22f89804c900aa073.chunk.js",
      "/69.ee9dffcd1022064e3072.chunk.js",
      "/70.4bb2cd6e2b5ec21e2d4a.chunk.js",
      "/71.9a7cfc2cfc06b88c22ad.chunk.js",
      "/72.076195dc13051c05ecbc.chunk.js",
      "/73.87df2ebaded45f01e5b3.chunk.js",
      "/74.e888aeff3cb1c0bad2e0.chunk.js",
      "/75.7933165aca57811e2c07.chunk.js",
      "/76.10237a5a2cbd746856be.chunk.js",
      "/77.8de9d3ad877b5b9109c5.chunk.js",
      "/78.5bc3bb502e09c8cb3920.chunk.js",
      "/79.a4f29d8637ced83fc423.chunk.js",
      "/80.76e1f9a800ba941501cc.chunk.js",
      "/81.ba72421d34648b0abf0d.chunk.js",
      "/82.65c684265e7c2ab210b1.chunk.js",
      "/83.8881a829a0978e21a371.chunk.js",
      "/84.051ac65b72a778d6e469.chunk.js",
      "/85.b24a2a7edc06263c8699.chunk.js",
      "/86.8da314dd7ab80f159cdc.chunk.js",
      "/87.af1e4f9346dd139aa308.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "7c285c265a562bef15d0ffcf967c599c9478a588": "/vendor.59bdf39c3407d6fe9a31.chunk.js",
    "73247c3f55769eadcb9d12198d0ddb8d6a273d35": "/1.9c1b3e793c048e257b47.chunk.js",
    "0dcc9e4a8937a676928839cbcf5347d4ba281ea7": "/2.eb663ebc3f5370694338.chunk.js",
    "7d8761303d4599c7c9af622cdf20987453099f43": "/3.d307013d2765bb0020d0.chunk.js",
    "26cb80d2fba8f15f671ab1f4048f67b0539498dd": "/4.dd57f55ac130d98b32e0.chunk.js",
    "c375d1892e837f809a312daa7ec837b4ee196d7c": "/5.e9620447ba5aa95ffc33.chunk.js",
    "754d16f2d79b9026b7e2f3bdddac4fd4d3ce782d": "/6.764bcca204cb21ef4ac7.chunk.js",
    "fbba5c0bcce6e64f9bc9fc0a6e3d4f5fa39f69e9": "/7.81a31ff7ebe26813af0d.chunk.js",
    "afb3019c3055b64ba85d3b16b50a1f75f8752b23": "/8.f502f41c4d719f9f4af5.chunk.js",
    "0351fa59f1dd2a18644b118f5f0e6da18894509b": "/9.978b08f7f77c60d1e4e8.chunk.js",
    "9ef2ca6ee438ead7d1bcfbf1ff31109258fc6332": "/10.6748c662e62e3a2a25a2.chunk.js",
    "5528caf9c867e43de72d638ff9c4a592a713f18b": "/11.ff4abc55df2508e6c425.chunk.js",
    "92b9b4466d5cb706a1cd36d3dfe8e4e99b34bc44": "/main.e34a3d376afe4b48c07f.chunk.js",
    "9143320104642d45bd27f7fcb78c9b406f7839da": "/runtime~main.f32c982bcd33a896a0d1.js",
    "31172e8103473cacbdc41b051789391b05fd82c7": "/14.0026277a08bb5c452c36.chunk.js",
    "6782c4e02297573ec7c0ba8b34906782442bd5df": "/15.a3f6f36ccd9b87200921.chunk.js",
    "eadcf2d778ec4d2d6f57386f292df13ff45acc69": "/16.38c7627154a6b5712530.chunk.js",
    "5abef3f77c845f7a56c03d7263c65b2ae9b71445": "/17.f10d30aae678168130e4.chunk.js",
    "ebf7b41a143fa91b0fc608203cab6548b8b129da": "/18.a697ff56dc42eadd60e7.chunk.js",
    "7a037595bf18bccf29e295ef1db36fba0bdce1c4": "/19.4229ce6b7a53a87acea4.chunk.js",
    "b57531cb4aad513dac1f74dd7beea96a553a4b23": "/20.36c7cb3334daa256380e.chunk.js",
    "a7e763c9dbe7aa22ca13349639e6f0d6d39e8b01": "/21.1b476c3ebb3ec6e9fc71.chunk.js",
    "ad5175f20878df3721e35a67f02e3306d023b16e": "/22.bc8c9836810cda9cccc6.chunk.js",
    "9cfc41bc2cc2789bed0e0b633f6998098dcad332": "/23.8d5c6fffcaafd9bdcf29.chunk.js",
    "e78f3962ddde8d90ac0f5e4d74b0a3d0397fcfb8": "/24.dad69ee71a8bbb74c680.chunk.js",
    "fc7103cf5b639a9eef2fd75a3943f6870fa16560": "/25.7464002c267fcdac64a9.chunk.js",
    "abc42758c3845a29b2c6e80d1652da16fa5aa850": "/26.31724035366728cac998.chunk.js",
    "047ee4c2d202ab2a1deadbc15698a562659f3db8": "/27.9c1a0eb57785e3a9b332.chunk.js",
    "21fd369984da964a09e74c19b7b2fcb8d3728761": "/28.6b844bce9bc81b4c26de.chunk.js",
    "c53d56df77a7447063fa4fa85cd3d2f36037326b": "/29.f71e68f9293154102085.chunk.js",
    "8a121e0efa7466b2e41200b375b2eb14ff22eaf5": "/30.08e2d71c0f613830e428.chunk.js",
    "f959f07829f0804d94a180fdd4a91a21eaeec151": "/31.929b6cb1b42c3576dc04.chunk.js",
    "413d0e7df9559b7b909b0f9dc7382854649447b7": "/32.3fa9deaa255367aab1d8.chunk.js",
    "05959353ce6ab926400594ca32d595496c50e277": "/33.a8119f82fcbe2b6c14f2.chunk.js",
    "0f6f3ab3c23d3b1a00f120a2eb56d3d29edf7d09": "/34.22e479bd03d6b2691667.chunk.js",
    "6480e972fdd2d090d5088deab1709a29c1efa5a8": "/35.2efaa6fdcb9206cc89c3.chunk.js",
    "c75befa30973be0429555773e71060302fb0a204": "/36.651d2e0665ff616bbfea.chunk.js",
    "e7fd3fd0c529cbd8640fb8adbe2a9dd688b85ffd": "/37.b66761dcce9fa4ca6c71.chunk.js",
    "bd75184a4dab94b224c9f475982f8bacf3ab6619": "/38.34eecc6c765957fb7f74.chunk.js",
    "cb2b90d962c15e39251cc41c04ebcbe21c36189b": "/39.1232cc558baad593bfd7.chunk.js",
    "71ddc1b4df9ac6b0f79867a90c1769788b78f6b7": "/40.9165549873878002b108.chunk.js",
    "ffcf272298f30d7fbac5938dbbc107823af70237": "/41.96c8d8ef9170c422c291.chunk.js",
    "cab77f89e497b633d7fa910a50ac02d2384a27a8": "/42.4a4edbf9f573ee3a1958.chunk.js",
    "c327b2943d17312dc3a57709d752e43fd9370a22": "/43.30834dc915161558a598.chunk.js",
    "db27a0edb5f77b8ce92f7b86d6440ee5800aec0f": "/44.4c6554a60adcb5865a4f.chunk.js",
    "a54a00c8d26fca3663e473ba6d4ac5e8269b4de0": "/45.3945d12d75a4cea57137.chunk.js",
    "043c2540d1b8c5e586ac51ac50d123d49f38204f": "/46.f3804bbea6c6d2778442.chunk.js",
    "b323c344b091ad4d2b7584fd6755472d3de46e6e": "/47.7ba122d8950ce4f9dc9b.chunk.js",
    "5085f360f867e429d88cd2e51248d755a304e99f": "/48.6ba75f0259af5b981f5b.chunk.js",
    "f8897686f98490e98908f0bd12e78e200ba43b48": "/49.9bf32306ff767322b48e.chunk.js",
    "9e388d104967e4f6f690d4788cdd52d009fc2ef4": "/50.9a27e6696c03a03e7d36.chunk.js",
    "29afbd741f7277f31dfc0ad315a3f381ecac47e6": "/51.04ac1583b58cb924a861.chunk.js",
    "0fd1adc59a288590b345ffed8e11519c44762cad": "/52.6e467181788fa3a92be2.chunk.js",
    "0e25956182cd97f312cd4c8dc8ac591d29274f5f": "/53.74d8fd21d2651c8d9bc0.chunk.js",
    "cd73b73bd61993c12526bfe49223f2a9732a52b9": "/54.bedc8d4eb796855a2edd.chunk.js",
    "5a09193e974d4c6ed8cb80bba058c4bde3d0772e": "/55.8376e2c23abd2eeeade9.chunk.js",
    "1272f633ac40427f928dd4843a3c99c0dfc47ae8": "/56.733a12a5d7eb1c3b2fd8.chunk.js",
    "9433b00e6fe45979f9d11ffff4b46581b581022b": "/57.fc43ee9bfc263dda2c68.chunk.js",
    "59eabd627c9ae0a7e5c02b2b77ede2d3402e82ca": "/58.995a92808244c5b4fbce.chunk.js",
    "ddbf91097ab859bd5e949b233bc5838b3154e196": "/59.742146166e65b2bc38b4.chunk.js",
    "dcb1a4de431e8d6722394a31b464095bcc68eae2": "/60.e7b24574eeb9bcebed86.chunk.js",
    "b5c5ccfa4c5a7f1ba12e35cb99fbeffb28b311da": "/61.a4d38112c1bf44e699e8.chunk.js",
    "6b25ff3e9c924c07de47b201c4b8181ebed14be8": "/62.77e541ea9ceb88222beb.chunk.js",
    "5b809b190cb0f7db76e52b7c9081716606b56fa2": "/63.2693efb9a5136888f4bc.chunk.js",
    "a497d4824548c0c76de281295f5c083c81771307": "/64.fdaa90800546d3169b4b.chunk.js",
    "25fdfb16ea513807305b07e99308b2e10f240838": "/65.629eec2602fa8edceeca.chunk.js",
    "dd0b65ef298906344e439108e712ad6c4956bbe0": "/66.6de6fca17ea3a2d1307f.chunk.js",
    "82e59bba57fcbf149ee80e2e20f74000a09ec80e": "/67.fabed1cfd19a093c8057.chunk.js",
    "8b9b05b1ffd3a6591f899033de065abc0e4b6aed": "/68.51d22f89804c900aa073.chunk.js",
    "1eebcee487b30dbbb94256200636086c456a9a44": "/69.ee9dffcd1022064e3072.chunk.js",
    "5709d409a0f666b05d71e4428f8b9146982a89d1": "/70.4bb2cd6e2b5ec21e2d4a.chunk.js",
    "fe29c04be212848b82fc977b6156dde502a1c92e": "/71.9a7cfc2cfc06b88c22ad.chunk.js",
    "3a2163621af023ab8326719a96fa4e12a1bd76ef": "/72.076195dc13051c05ecbc.chunk.js",
    "110728b15e2907a5679cbf4c5443ba58da8e4a70": "/73.87df2ebaded45f01e5b3.chunk.js",
    "e199b78ca4d4f09a1fe3c17b8388dec18053bd38": "/74.e888aeff3cb1c0bad2e0.chunk.js",
    "6b2fd157c00fd5f55193b75c7c6e28d59730f0e9": "/75.7933165aca57811e2c07.chunk.js",
    "5c7affaf0e3cd5224970fdaa2956cec2de4a1f25": "/76.10237a5a2cbd746856be.chunk.js",
    "6e22ed350b576632bf9a33762883537803e22678": "/77.8de9d3ad877b5b9109c5.chunk.js",
    "9975e732ac28ad83604fda489081a1d3c5d5d365": "/78.5bc3bb502e09c8cb3920.chunk.js",
    "0595cdba73dc8e3a65add3b01b8ee8c55bd5bf4a": "/79.a4f29d8637ced83fc423.chunk.js",
    "54d7c32881a317bc12b4b4ee5c261fdd2815c659": "/80.76e1f9a800ba941501cc.chunk.js",
    "809e170c6f3440424bc00bd1db44d00e26183839": "/81.ba72421d34648b0abf0d.chunk.js",
    "4092de419ba2d749a77cd5b187a283bcfef4fc06": "/82.65c684265e7c2ab210b1.chunk.js",
    "80ef13b6fcbb4e9a1939d0b33e7c570370e6e626": "/83.8881a829a0978e21a371.chunk.js",
    "4469e707efe6274b8b73f7d3e006548e0cc80549": "/84.051ac65b72a778d6e469.chunk.js",
    "617bf18d230fdedf50a352409bfaa5649ba04d74": "/85.b24a2a7edc06263c8699.chunk.js",
    "af73540b72b970d3412d602a6a9f4ee25ceecba7": "/86.8da314dd7ab80f159cdc.chunk.js",
    "a87635a883d82f52beb4e0cb3d7dd6dccc737a7c": "/87.af1e4f9346dd139aa308.chunk.js",
    "3e7a830d6eb59ea7a90e33f6981cc08043545928": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "3/29/2022, 7:08:28 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });